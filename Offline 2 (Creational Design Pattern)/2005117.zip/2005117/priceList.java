class priceList{
    static final int chocolate_Shake_Base_Price = 230;
    static final int coffee_Shake_Base_Price = 250;
    static final int strawberry_Shake_Base_Price = 200;
    static final int vanilla_Shake_Base_Price = 190;
    static final int zero_Shake_Base_Price = 200;
    static final int lactoseFree_Charge = 60;
    static final int candyOnTop_Charge = 50;
    static final int cookieOnTop_Charge = 40;
}